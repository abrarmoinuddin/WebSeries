package finalProject;

import java.util.*;

import finalProject.MyNode;
import finalProject.MyInvalidAcessException;
import finalProject.MyList;
import finalProject.MyListIterator;


public class MyList<T> {

	MyNode<T> data;
	private MyNode<T> tail;
	
	public MyList() {
		data = null;
		tail = null;
	}
    
	public MyList(T type) {
		MyNode<T> temp = new MyNode<T>(type);
		if(data == null) {
			data = temp;
			tail = temp;
		} else {
			tail.next = temp;
		}		
	}
	
    public MyList(T[] type) {
		
		//Assign list to the data
		for(T item:type) {
			
			MyNode<T> temp = new MyNode<T>(item);
			if( data == null) {
				data = temp;
			} else {
				tail.next = temp;
			}
			tail = temp;
		}
	}
	
    public boolean isEmpty() {
		// if head list is empty
		return data == null;
	}
	
	public Object[] toArray() {
		ArrayList<T> temp = new ArrayList<T>();
		
		MyNode<T> currentNode = data;
		
		//Check if first node is set
		if(!this.isEmpty()) {
			// Only single node exists
			temp.add(currentNode.content);
			
			while(currentNode.next != null) {
				currentNode = currentNode.next;
				temp.add(currentNode.content);
			}
		} else {
			System.out.println("Warning: List has no element.");
		}
		
		return temp.toArray();
	}
	
	@SuppressWarnings("unchecked")
	public MyList<T> copy() {
		return new MyList<T>((T[]) this.toArray());
	}
	
	public T head() {
		if(data == null) {
			throw new MyInvalidAcessException("", 1);
		}
		return data.content;
	}
	
	public MyNode<T> getFirst() {
		if(data == null) {
			throw new MyInvalidAcessException("Failed to Return 1 on Empty List.", 50);
		}
		return data;
	}
	
	public MyNode<T> getLast() {
		return tail;
	}
	
	@SuppressWarnings("unchecked")
	public MyList<T> tail() {
		ArrayList<T> temp = new ArrayList<T>();
		
		//Reset List
		MyNode<T> currentNode = data;
		while(currentNode.next != null) {
			currentNode = currentNode.next; 
			temp.add(currentNode.content);
		}
		return new MyList<T>((T[]) temp.toArray());
	}
	
	public T end() {
		if(data == null) {
			throw new  MyInvalidAcessException("", 2);
		}
		return tail.content;
	}
	public void append (T type) {
		MyNode<T> temp = new MyNode<T>(type);
		if(data == null) {
			data = temp;
		}
		else {
			tail.next = temp;
		}
		tail = temp;
	}
	
	@SuppressWarnings("unchecked")
	public void concat (MyList<T> lc) {
		// For concatenation, We will be simply appending the data under loop. 
		for(Object item:lc.toArray()) {
			this.append((T) item);
		}
	}
	public MyListIterator<T> iterator() {
		return new MyListIterator<T>(this);
	}

}
