package finalProject;

import finalProject.MyNode;

public class MyNode<T> {

	public T content;
	public MyNode<T> prev;
	public MyNode<T> next;
	
	public MyNode(T type) {
		content = type;
		prev = null;
		next = null;
	}

}
