package finalProject;

public class MyInvalidAcessException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;
	
	private Integer code;

	MyInvalidAcessException(String errorMessage, Integer code){
		  super(errorMessage);
		  this.code = code;
	}
	
	@Override
    public String getMessage() {
		String msg = "";
		switch(this.code) {
			case 1: 
				msg = "Invalid head() call: empty list";
				break;
			case 2:
				msg = "Invalid end() call: empty list";
				break;
			case 11:
				msg = "Invalid next() call: hasNext() false";
				break;
			case 12:
				msg = "Invalid previous() call: hasPrevious() false";
				break;
			case 13:
				msg = "Invalid set(T v) call: undefined current position";
				break;
			case 14: 
				msg = "Invalid remove() call: undefined current position";
				break;
			default:
				msg = super.getMessage();
		}
        return msg;
    }
}
