package finalProject;

import finalProject.MyList;
import finalProject.MyListIterator;

public class MyMainClass {

	public static void main(String[] args) {
		Integer data[] = {1,2,3,4,5};
		MyList<Integer> testing = new MyList<Integer>(data);
		
		System.out.println(" MyList as toArray : ");
		for(Object i:testing.toArray()) {
			System.out.print(i + " ");
		}
		
		System.out.println("\n Copy to changes(Testing) ...");
		MyList<Integer> second = testing.copy();
		testing.append(7);
		second.append(3);
		for(Object i:testing.toArray()) {
			System.out.print(i + " ");
		}
		System.out.println("\n");
		for(Object i:second.toArray()) {
			System.out.print(i + " ");
		}
		
		System.out.println("\n Concatenation of 2 Lists: ");
		testing.concat(second);
		for(Object i:testing.toArray()) {
			System.out.print(i + " ");
		}
		
		System.out.println("\n Get Data");
		System.out.print(testing.head());

		System.out.println("\n Get Tail");
		for(Object i: testing.tail().toArray()) {
			System.out.print(i + " ");
		}
		
		System.out.println("\n Next Iteration ");
		MyListIterator<Integer> x = testing.iterator();
		
		while(x.hasNext()) {
			System.out.print(x.next() + ", ");
		}
		
		System.out.println("\n Iterator Previous ");
		while(x.hasPrevious()) {
			System.out.print(x.previous() + ", ");
		}
		
		
		// Testing Exceptions
		System.out.println("\nException is: ");
		try {
			// Empty List Head call
			MyList<String> first = new MyList<String>();
			System.out.println(first.head());
			
		} catch (Exception e) {
			System.out.println("Exception: "+ e.getMessage());
		}
		
		try {
			// Empty List Head call
			MyList<String> sec = new MyList<String>();
			System.out.println(sec.end());
		} catch (Exception e) {
			System.out.println("Exception: "+ e.getMessage());
		}
		
		try {
			// Next call on single node
			MyList<String> third = new MyList<String>();
			MyListIterator<String> y = third.iterator();
			System.out.println(y.next());
		} catch (Exception e) {
			System.out.println("Exception: "+ e.getMessage());
		}
		
		try {
			// Next call on single node
			MyList<String> fourth = new MyList<String>();
			MyListIterator<String> y = fourth.iterator();
			System.out.println(y.previous());
		} catch (Exception e) {
			System.out.println("Exception: "+ e.getMessage());
		}	
	}
}
