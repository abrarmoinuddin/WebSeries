package finalProject;

import finalProject.MyNode;
import finalProject.MyInvalidAcessException;
import finalProject.MyList;

public class MyListIterator<T> {

	private MyNode<T> cur; 
	private MyNode<T> itnext;
	private MyNode<T> prev;
	private MyList<T> list; 
	
	public MyListIterator(MyList<T> e) {
		//Set List on which we are iterating
		list 	= e;
		cur 	= null;
		itnext 	= null;
		prev 	= null;
	}
	
	public boolean hasNext() {
		// If current element is null. We will set list as first.
		if(cur == null) {
			cur = list.getFirst();
		}
		
		//We will fetch tail and return boolean
		return cur.next != null;
	}
	
	public T next() {
		// If current element is null and we are calling next. 
		// Will raise exception on it. 
		if(!this.hasNext()) {	
			throw new MyInvalidAcessException(null, 11);
		}
		T value = cur.next.content;
		//Switch the current index
		prev = cur;
		cur = cur.next;
		return value;
	}
	public boolean hasPrevious() {
		if( cur == null) {
			return false;
		}
		return cur != list.getFirst();
	}
	
	private MyNode<T> previousNode() {
		// This is a costly call in singly list. 
		// We will iterate from list start and get results
		MyNode<T> firstPosition = list.getFirst();
		MyNode<T> keyPosition = cur;
		MyNode<T> prevPosition = null;
		//Reset list and loop over and keep track on prev.
		while(firstPosition.next !=null) {
			prevPosition = firstPosition;
			firstPosition = firstPosition.next;
			if(firstPosition == keyPosition) {
				break;
			}	
		}
		
		return prevPosition;
	}
	
	public T previous() {
		
		if(!this.hasPrevious()) {
			throw new MyInvalidAcessException(null, 12);
		}
		
		cur = this.previousNode() ;
		return cur.content;
	}
	
	public void goToBegin() {
		cur = list.getFirst();
	}
	public void goToEnd() {
		cur = list.getLast();
	}
	public void set (T v) {
		if(cur == null) {
			throw new MyInvalidAcessException(null, 13);
		}
		cur.content = v;
	}
	public void add (T v ) {
		
		// First Case: First Node
		if(!this.hasPrevious()) {
			System.out.println("First Node");
			MyNode<T> temp = new MyNode<T>(v);
			if(this.hasNext()) {
				temp.next = this.list.data.next;
			} 
			this.list.data.next = temp;
			cur = temp;
		}
		
		// Second Case: Last Node
		if(!this.hasNext()) {
			// We will simply append in this case
			this.list.append(v);
		}
		
		// Third Case: Middle 
		if(this.hasPrevious() && this.hasNext()) {
			MyNode<T> temp = new MyNode<T>(v);
			this.previousNode().next = temp;
			temp.next = cur.next;
		}
		
	}
	public void remove() {
		if(cur == null) {
			throw new MyInvalidAcessException(null, 14);
		}
		
		// First Case: Check if it's first node
		if(!this.hasPrevious()) {
			if(this.hasNext()) {
				this.list.data = cur.next;
				cur = cur.next;
			} else {
				this.list.data = null;
			}
		}
		// Second Case: Check if it's last node 
		if(!this.hasNext()) {
			cur = this.previousNode();
			cur.next = null;
		}
		
		// Third Case: Check if it's in middle
		// Previous Node -> next == Current Node -> Next
		// We will just use cur.next reference and assign it to prev.next
		if(this.hasPrevious() && this.hasNext()) {
			this.previousNode().next = cur.next;
		}
	}
}
