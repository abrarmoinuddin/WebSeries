﻿using hiTechDistribution.Business;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hiTechDistribution.GUI
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            {
                if (txtUserName.Text == "" || txtPass.Text == "")
                {
                    MessageBox.Show("Can not be Empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
                User user = new User();
                user.Username = txtUserName.Text;
                user.PassWord = txtPass.Text;
                int id = user.Login(user);
                if (id > 0)
                {
                    if (id == 1)
                    {
                        MisManagerForm mainform = new MisManagerForm();
                        this.Hide();
                        mainform.Show();
                    }
                    else if (id == 2)
                    {
                        MessageBox.Show("Sales Manager");
                        SalesManager mainform = new SalesManager();
                        this.Hide();
                        mainform.Show();
                    }
                    else if (id == 3)
                    {
                        MessageBox.Show("Order Clerks");
                        OrdersClerks mainform = new OrdersClerks();
                        this.Hide();
                        mainform.Show();
                    }
                    else if (id == 4)
                    {
                        MessageBox.Show("Accountant");
                        Accountants mainform = new Accountants();
                        this.Hide();
                        mainform.Show();
                    }
                    else
                    {
                        MessageBox.Show("Inventory Control");
                        InventoryCountrol mainform = new InventoryCountrol();
                        this.Hide();
                        mainform.Show();
                    }
                }
                else
                {
                    MessageBox.Show("Can not login", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
    