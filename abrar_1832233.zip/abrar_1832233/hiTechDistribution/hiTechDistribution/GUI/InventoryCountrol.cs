﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hiTechDistribution.GUI
{
    public partial class InventoryCountrol : Form
    {
        public InventoryCountrol()
        {
            InitializeComponent();
        }
        private void cleanTextBox()
        {
            textBoxBookISBN.Text = string.Empty;
            textBoxBookTitle.Text = string.Empty;
            textBoxPrice.Text = string.Empty;
            textBoxYearPublished.Text = string.Empty;
            textBoxQuantity.Text = string.Empty;
            textBoxCategory.Text = string.Empty;
            textBoxAuthorId.Text = string.Empty;
            textBoxPublishedId.Text = string.Empty;
            textBoxSearch.Text = string.Empty;
        }
        
        private void buttonList_Click(object sender, EventArgs e)
        {
           
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            Book book = new Book();

            int searchID = Convert.ToInt32(textBoxSearch.Text.Trim());
            Book book1 = HI_TECHEntities2.Book.Find(searchID);
            if (book1 != null)
            {
                MessageBox.Show("Duplicate ISBN");
                textBoxSearch.Clear();
                textBoxSearch.Focus();
                return;
            }
            else
            {
                book.ISBN = Convert.ToInt32(textBoxSearch.Text.Trim());
            }
            book.title = textBoxBookTitle.Text.Trim();
            book.unitPrice = Convert.ToInt32(textBoxPrice.Text.Trim());
            book.yearPublished = Convert.ToInt32(textBoxYearPublished.Text.Trim());
            book.QOH = Convert.ToInt32(textBoxQuantity.Text.Trim());
            book.category = textBoxCategory.Text.Trim();
            book.Author_id = Convert.ToInt32(textBoxAuthorId.Text.Trim());
            book.Published_id = Convert.ToInt32(textBoxPublishedId.Text.Trim());
            HI_TECHEntities2.Book.Add(book);
            MessageBox.Show("Book Saved successfully");
            cleanTextBox();
        }
        private void PopulateList()
        {
            //lambda
            // var empList =  dbEntities.Employees.Select(x => x);

            //linq
            var empList = from emp in HI_TECHEntities2.Book

                          select book;
            listViewInventory.Items.Clear();
            foreach (var book in bookList)
            {
                ListViewItem item = new ListViewItem(Convert.ToString(book.ISBN));
                item.SubItems.Add(book.Title);
                item.SubItems.Add(book.Price);
                item.SubItems.Add(book.Year);
                item.SubItems.Add(book.Quantity);
                item.SubItems.Add(book.Category);
                item.SubItems.Add(book.AuthorId);
                item.SubItems.Add(book.PublishedId);
                listViewInventory.Items.Add(item);
            }

        }
    }
}
