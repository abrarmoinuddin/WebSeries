﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using hiTechDistribution.Business;
using System.Data;

namespace hiTechDistribution.DataAccess
{
    public static class UserDB
    {
        public static SqlConnection connDB = UtilityDB.ConnectionDB();
        public static SqlCommand cmd = new SqlCommand();
        public static int Login(User user)
        {
            if (connDB.State == ConnectionState.Closed)
            {
                connDB = UtilityDB.ConnectionDB();
                cmd = new SqlCommand();
            }
            cmd.Connection = connDB;
            cmd.CommandText = string.Format("select * from Users where UserName='{0}' and Pass='{1}'", user.UserName, user.PassWord);
            SqlDataReader reader = cmd.ExecuteReader();
            int count = 0;
            while (reader.Read())
            {
                count++;
            }
            reader.Close();
            cmd.Dispose();
            connDB.Close();
            return count;
        }
    }
}