﻿using System;
using hiTechDistribution.Business;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace hiTechDistribution.DataAccess
{
    public static class CustomerDB
    {
        public static SqlConnection connDB = UtilityDB.ConnectionDB();
        public static SqlCommand cmd = new SqlCommand();
        public static bool Save(Book book)
        {
            bool result = true;
            try
            {
                if (connDB.State == ConnectionState.Closed)
                {
                    connDB = UtilityDB.ConnectionDB();
                    cmd = new SqlCommand();
                }
                cmd.Connection = connDB;
                cmd.CommandText = string.Format("insert into Books values('{0}','{1}')", book.title, book.Author);
                cmd.ExecuteNonQuery();
                connDB.Close();
            }
            catch (Exception)
            {
                result = false;
                throw;
            }
            return result;
        }
        public static DataTable ListAllBooks()
        {
            if (connDB.State == ConnectionState.Closed)
            {
                connDB = UtilityDB.ConnectionDB();
                cmd = new SqlCommand();
            }
            cmd.Connection = connDB;
            cmd.CommandText = "select * from Books";
            SqlDataReader reader = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader);
            reader.Close();
            cmd.Dispose();
            connDB.Close();
            return dt;
        }
    }
}