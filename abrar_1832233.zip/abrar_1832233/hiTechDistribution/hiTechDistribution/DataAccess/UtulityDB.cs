﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hiTechDistribution.DataAccess
{
    public static class UtilityDB
    {
        public static SqlConnection ConnectionDB()
        {
            SqlConnection connDB = new SqlConnection("data source =(local)\\MSSQLSERVER2017 ; database=HI_TECH ; Integrated Security=SSPI");
            connDB.Open();
            return connDB;
        }
    }
}