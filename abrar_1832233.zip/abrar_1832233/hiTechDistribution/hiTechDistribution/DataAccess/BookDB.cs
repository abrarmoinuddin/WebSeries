﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using hiTechDistribution.Business;

namespace hiTechDistribution.DataAccess
{
    public static class BookDB
    {
        public static SqlConnection connDB = UtilityDB.ConnectionDB();
        public static SqlCommand cmd = new SqlCommand();
        public static DataTable ReadBook()
        {
            if (connDB.State == ConnectionState.Closed)
            {
                connDB = UtilityDB.ConnectionDB();
                cmd = new SqlCommand();
            }
            cmd.Connection = connDB;
            cmd.CommandText = "select * from Book";
            SqlDataReader reader = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader);
            reader.Close();
            cmd.Dispose();
            connDB.Close();
            return dt;
        }
        public static bool SaveBook(Book book)
        {
            bool result = true;
            try
            {
                if (connDB.State == ConnectionState.Closed)
                {
                    connDB = UtilityDB.ConnectionDB();
                    cmd = new SqlCommand();
                }
                cmd.Connection = connDB;
                cmd.CommandText = string.Format("insert into Book values( {0},'{1}','{2}','{4}','{5}','{6}','{7}')", book.ISBN, book.title, book.unitPrice, book.yearPublished, book.QOH, book.category, book.Author_id, book.Published_id);
                cmd.ExecuteNonQuery();
                connDB.Close();
            }
            catch (Exception)
            {
                result = false;

            }
            return result;
        }

        internal static bool Update(Business.Book book)
        {
            throw new NotImplementedException();
        }

        internal static bool SaveBook(Business.Book book)
        {
            throw new NotImplementedException();
        }

        public static bool Update(Book book)
        {
            bool res = true;
            try
            {
                if (connDB.State == ConnectionState.Closed)
                {
                    connDB = UtilityDB.ConnectionDB();
                    cmd = new SqlCommand();
                }
                cmd.Connection = connDB;
                cmd.CommandText = string.Format("update Book set ISBN='{0}',Title='{1}',UnitPrice='{2}',YearPublished='{3}' ,QOH='{4}',Category='{5}'  where ISBN={5}", book.ISBN, book.title, book.unitPrice, book.yearPublished, book.QOH, book.category, book.Author_id, book.Published_id);
                cmd.ExecuteNonQuery();
                connDB.Close();

            }
            catch (Exception)
            {
                res = false;
                throw;
            }
            return res;
        }

        public static bool Delete(Book book)
        {
            bool res = true;
            try
            {
                if (connDB.State == ConnectionState.Closed)
                {
                    connDB = UtilityDB.ConnectionDB();
                    cmd = new SqlCommand();
                }
                cmd.Connection = connDB;
                cmd.CommandText = "delete from Book where ISBN=" + book.ISBN;
                cmd.ExecuteNonQuery();
                connDB.Close();
            }
            catch (Exception)
            {
                res = false;
                //throw;
            }
            return res;
        }
        public static DataTable Search(int ISBN)
        {
            if (connDB.State == ConnectionState.Closed)
            {
                connDB = UtilityDB.ConnectionDB();
                cmd = new SqlCommand();
            }
            cmd.Connection = connDB;
            cmd.CommandText = "select * from Book where ISBN=" + ISBN;
            SqlDataReader reader = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader);
            reader.Close();
            cmd.Dispose();
            connDB.Close();
            return dt;
        }
    }

}

