﻿using hiTechDistribution.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace hiTechDistribution.Business
{
     public class Book
    {
        private string title;
        private string ISBN;
        private string unitPrice;
        private string yearPublished;
        private string QOH;
        private string category;
        private string Author_id;
        private string Published_id;

        public string Title { get => title; set => title = value; }
        public string Isbn { get => ISBN; set => ISBN = value; }
        public string UnitPrice { get => unitPrice; set => unitPrice = value; }
        public string YearPublished { get => yearPublished; set => yearPublished = value; }
        public string Qoh { get => QOH; set => QOH = value; }
        public string Category { get => category; set => category = value; }
        public string AuthorID { get => Author_id; set => Author_id = value; }
        public string PublishedID { get => Published_id; set => Published_id = value; }

        public DataTable ReadBook()
        {
            return BookDB.ReadBook();
        }
        public bool SaveBook(Book book)
        {
            return BookDB.SaveBook(book);
        }
        public bool Update(Book book)
        {
            return BookDB.Update(book);
        }
        public bool Delete(Book book)
        {
            return BookDB.Delete(book);
        }
        public DataTable Search(int ISBN)
        {
            return BookDB.Search(ISBN);
        }
    }
}


