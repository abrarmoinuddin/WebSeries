﻿using hiTechDistribution.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hiTechDistribution.Business
{
    public class User
    {
        private string username;
        private string password;
        public string UserName { get => username; set => username = value; }
        public string PassWord { get => password; set => password = value; }
        public int Login(User user)
        {
            return UserDB.Login(user);
        }
    }
}