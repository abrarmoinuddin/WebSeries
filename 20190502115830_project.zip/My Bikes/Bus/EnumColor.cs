﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mybikes.Bus
{
    public enum EnumColor
    {
        Undefined,
        Red,
        Blue,
        Black,
        Yellow
    }
}