﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mybikes.Bus
{
    public enum EnumStyle
    {
        Undefined,
        Adult,
        Adolescence,
        Kids
    }
}