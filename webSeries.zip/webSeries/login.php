<?php ob_start(); ?>

<?php include"includes/header.php" ?>
<?php include"includes/TopBar.php" ?>
<?php include"classes/Message.php"?>
<?php include"classes/User.php"?>

<style>
    
    body{
            background-image: url("images/LoginBackground.jpg");   
            background-size: cover;
        background-position: center;
    }
    
</style>
<body>
    
  
    <?php

				
				if(!isset($_SESSION)){
					session_start();
				}		
				if(isset($_POST["Submit"])){
					
						$Username = $_POST["Username"];
						$Password = $_POST["Password"]; 
						
						if( User::Login($Username, $Password) ){
							$_SESSION['Username'] = $Username;
							$_SESSION['User_ID']  = User::Get_ID($Username);
							$_SESSION['Role_ID']  = User::Get_Role($Username);
							//SAVE LOGIN IN COOKIE
							if (isset($_POST["Remember_Me"]) ){
								$expiration = time() + (60*60*24*365);//365 days
								setcookie('Cookie_Username', $_POST["Username"], $expiration);
								setcookie('Cookie_Password', $_POST["Password"], $expiration);
							}
							
							if($_SESSION['Role_ID'] == 1){
								header('Location: Admin/index.php');
							}else
							if($_SESSION['Role_ID'] == 2){
								header('Location: Member/index.php');
							}
						}else{
							Message::Show("Your Username and Password do not match with our records !", Message::$Full_Size, Message::$Error);
						}
						
					}
					
					$Cookie_Username = '';
					$Cookie_Password = '';
					if(isset($_COOKIE["Cookie_Username"]) && $_COOKIE["Cookie_Password"]){
						$Cookie_Username = $_COOKIE["Cookie_Username"];
						$Cookie_Password = $_COOKIE["Cookie_Password"];
					}
				?>
    
    
  <div class="container" style="margin-top: 50px; ">
    <div class="row">
      <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
        <div class="card card-signin my-5">
          <div class="card-body">
            <h5 class="card-title text-center">Sign In</h5>
            <form class="form-signin" action="#" method="post">
              <div class="form-label-group">
                <input type="text" name="Username" value ="<?php echo $Cookie_Username?>" class="form-control" placeholder="Username" required autofocus>
                <label for="inputUsername"></label>
              </div>

                
                
              <div class="form-label-group">
                <input type="password" name="Password"
                value ="<?php echo $Cookie_Password?>"class="form-control" placeholder="Password" required>
                <label for="inputPassword"></label>
              </div>

              <div class="custom-control custom-checkbox mb-3">
                <input type="checkbox" class="custom-control-input" id="customCheck1">
                <label class="custom-control-label" for="customCheck1">Remember password</label>
              </div>
              <button class="btn btn-lg btn-primary btn-block text-uppercase" type="submit" name="Submit">Sign in</button>
              <hr class="my-4">
              
            </form>
            <h6>Don't have an account? <a href="register.php">Sign Up</a></h6>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>