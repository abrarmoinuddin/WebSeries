
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


CREATE TABLE `series` (
  `ID` int(11) NOT NULL,
  `Name` varchar(32) NOT NULL,
  `Creator` varchar(100) NOT NULL,
  `Year` int(4) NOT NULL,
  `Episodes` int(4) NOT NULL,
  `Seasons` int(4) NOT NULL,
  `Genres` varchar(32) NOT NULL,
  `Language` varchar(32) NOT NULL,
  `Image` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `series` (`ID`, `Name`, `Creator`, `Year`, `Episodes`, `Seasons`, `Genres`, `Language`, `Image`) VALUES
(1, 'Dexter', 'James Manos Jr' , 2006, 96 , 8 , 'Crime|Drama|Mystery|Thriller', 'English',  'Dexter.jpg\n'),
(2, 'Game of Thrones', 'David Benioff , D.B.Weiss' , 2011, 73 , 8 , 'Action|Adventure|Drama|Fantasy|Romance', 'English', 'GOT.jpg\n'),
(3, 'Breaking Bad', 'Vince Gilligan' , 2008, 62 , 5 , 'Crime|Drama|Thriller', 'English',  'BreakingBad.jpg\n'),
(4, 'Chernobyl', 'Craig Mazin' , 2019, 5 , 1 , 'Drama|History', 'English', 'Chernobyl.jpg\n'),
(5, 'Prison Break', 'Paul Scheuring' , 2005, 91 , 6 , 'Action|Crime|Drama|Mystery|Thriller', 'English',   'PrisonBreak.jpg\n'),
(6, 'Friends', 'David Crane , Marta Kauffman' , 1994, 236 , 10 , 'Comedy|Romance', 'English',  'Friends.jpg\n'),
(7, 'How I Met Your Mother', 'Carter Bays , Craig Thomas' , 2005, 208 , 9 , 'Comedy|Romance', 'English',  'mother.jpg\n'),
(8, 'Person of Interest', 'Jonathan Nolan' , 2011, 103 , 5 , 'Action|Crime|Drama|Mystery|Sci-Fi|Thriller', 'English',  'POI.jpg\n'),
(9, 'Orange Is the New Black', 'Jenji Kohan' , 2013, 91 , 7 , 'Comedy|Crime|Drama', 'English',  'Orangeisthenewblack.jpg\n'),
(10, 'Sherlock', 'Mark Gatiss , Steven Moffat' , 2010, 15 , 4 , 'Crime|Drama|Mystery|Thriller', 'English',  'Sherlock.jpg\n'),
(11, 'Arrow', 'Greg Berlanti , Marc Guggenheim , Andrew Kreisberg' , 2012, 170 , 8 , 'Action|Adventure|Drama|Crime|Sci-Fi|Mystery', 'English',  'Arrow.jpg\n'),
(12, 'The Flash', 'Greg Berlanti , Geoff Johns , Andrew Kreisberg' , 2014, 125 , 6 , 'Action|Adventure|Drama|Sci-Fi', 'English',  'TheFlash.jpg\n'),
(13, 'Daredevil', 'Drew Goddard' , 2015, 39 , 3 , 'Action|Crime|Drama|Fantasy|Sci-Fi|Thriller', 'English',  'Daredevil.jpg\n'),
(14, 'The Punisher', 'Steve Lighfoot' , 2017, 26 , 2 , 'Action|Adventure|Drama|Crime|Sci-Fi|Thriller', 'English',  'Punisher.jpg\n'),
(15, 'Fargo', 'Allison Tolman' , 2014, 40 , 4 , 'Crime|Drama|Thriller', 'English',  'Fargo.jpg\n'),
(16, 'Lost', 'J.J. Abrams, Jeffrey Lieber, Damon Lindelof' , 2004, 118 , 6 , 'Fantasy|Adventure|Drama|Sci-Fi|Thriller|Mystery', 'English',  'Lost.jpg\n');

CREATE TABLE `favorites` (
  `User_ID` int(11) NOT NULL,
  `series_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `favorites` (`User_ID`,`series_ID`) VALUES
(4, 2),
(4, 3),
(5, 2);


CREATE TABLE `ratings` (
  `User_ID` int(11) NOT NULL,
  `series_ID` int(11) NOT NULL,
  `Rating` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `ratings` (`User_ID`, `series_ID`, `Rating`) VALUES
(4, 1, 3),
(4, 2, 4),
(4, 3, 5),
(5, 2, 5),
(5, 4, 2);


CREATE TABLE `roles` (
  `Role_ID` int(11) NOT NULL,
  `Name` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `roles` (`Role_ID`, `Name`) VALUES
(1, 'Admin'),
(2, 'Member');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `User_ID` int(11) NOT NULL,
  `First_Name` varchar(25) NOT NULL,
  `Last_Name` varchar(25) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Username` varchar(25) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Salt` varchar(30) NOT NULL,
  `Role_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`User_ID`, `First_Name`, `Last_Name`, `Email`, `Username`, `Password`, `Salt`, `Role_ID`) VALUES
(4, 'sa', 'sa', 'sa@gmail.com', 'sa', '$2x$05$c12e01f2a13ff5587e1e9eEnjJ0Y3b88ZsWqHOO9ynejAnB5c.jQm', '$2x$05$c12e01f2a13ff5587e1e9e$', 2),
(5, 'demo', 'demo', 'demo@gmail.com', 'demo', '$2a$05$fe01ce2a7fbac8fafaed7Ox7.YZOJLWkeffuYjT8Oi6SQKQO0i.7m', '$2a$05$fe01ce2a7fbac8fafaed7c$', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `web_series`
--
ALTER TABLE `series`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `favorites`
--
ALTER TABLE `favorites`
  ADD PRIMARY KEY (`User_ID`,`series_ID`),
  ADD KEY `Favorites_series_ID_FK` (`series_ID`);

--
-- Indexes for table `ratings`
--
ALTER TABLE `ratings`
  ADD PRIMARY KEY (`User_ID`,`series_ID`),
  ADD KEY `ratings_seriesID_FK` (`series_ID`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`Role_ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`User_ID`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD UNIQUE KEY `Username` (`Username`),
  ADD KEY `User_Role_ID_FK` (`Role_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `series`
--
ALTER TABLE `series`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `User_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `favorites`);
--
ALTER TABLE `favorites`
  ADD CONSTRAINT `Favorites_series_ID_FK` FOREIGN KEY (`series_ID`) REFERENCES `series` (`ID`),
  ADD CONSTRAINT `Favorites_User_ID_FK` FOREIGN KEY (`User_ID`) REFERENCES `users` (`User_ID`);

--
-- Constraints for table `ratings`
--
ALTER TABLE `ratings`
  ADD CONSTRAINT `ratings_seriesID_FK` FOREIGN KEY (`series_ID`) REFERENCES `series` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `ratings_UserID_FK` FOREIGN KEY (`User_ID`) REFERENCES `users` (`User_ID`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `User_Role_ID_FK` FOREIGN KEY (`Role_ID`) REFERENCES `roles` (`Role_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
