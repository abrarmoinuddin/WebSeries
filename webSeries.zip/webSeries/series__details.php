<?php include "includes/header.php"?>
<?php include "classes/series.php"?>

<body>
	<div id="page" align="center">
		<div id="content" style="width:800px">
			<?php include "includes/TopBar.php" ?>
			<div id="contenttext">
		
				<div class="bodytext" style="padding:12px;" align="justify">
					
				<?php 
					if(isset($_GET['ID'])){
									
						$series = series::Search_By_ID($_GET['ID']);
						series::Display_Detail($series);
						
					}
						
				?>
				
				</div>
			</div>
		
		</div>
	</div>
	