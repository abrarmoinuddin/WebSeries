<?php include"includes/header.php" ?>
<?php include"includes/TopBar.php" ?>
<?php include"classes/series.php" ?>


<style>
    body {
        background-image: url(images/blur.jpg);
        opacity: 50%
    }
</style>
<body>

    
    <?php
$series_main = Series::ReadSeries()
    ?>
    
    <br> <br>
    <?php
    series::Display($series_main)
        ?>
    
</body>