<?php include "includes/header.php"?>
<?php include_once "../classes/series.php"?>
<?php include_once "../classes/Favorite.php"?>

<body>
	<div id="page" align="center">
		<div id="content" style="width:800px">
		
			<div id="contenttext">
		
				<div class="bodytext" style="padding:12px;" align="justify">
					
				<?php 
					if(!isset($_SESSION)){
						session_start();
					}
										
					$User_ID = $_SESSION['User_ID'];
					
					if(isset($_POST['Delete'])){
						$Series_ID = $_POST['Series_ID'];
						Favorite::Delete_Favorite($User_ID, $Series_ID);
					}
					
									
					$array = Series::Get_Favorite_Series($User_ID);
					Series::Display($array, TRUE);
					
					
				?>
				
				</div>
			</div>
			<?php include "includes/footer_menu.php"?>
		</div>
	</div>
	<?php include "includes/footer_links.php"; ?>