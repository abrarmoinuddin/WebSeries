<?php include "includes/header.php"?>
<?php include "classes/Message.php"?>
<?php include "classes/User.php"?>
<?php include"includes/TopBar.php" ?>

<style>
    
    body{
            background-image: url("images/Registerbackground.jpg  ")   ;
            background-size: cover;
        background-position: center;
    }
    
</style>
<body>
    
    
    <?php
					if(isset($_POST["Submit"])){
						
						$First_Name = $_POST["First_Name"];
						$Last_Name = $_POST["Last_Name"];
						$Email = $_POST["Email"];
						$Username = $_POST["Username"];
						$Password = $_POST["Password"]; 
						$Confirmed_Password = $_POST["Confirmed_Password"];
						
						if(User::Email_Exists($Email)){
							Message::Show("This email already exists ! Try again...", Message::$Full_Size, Message::$Error);
						}
						
						if(User::Username_Exists($Username )){
							Message::Show("This username already exists ! Try again...", Message::$Full_Size, Message::$Error);
						}
						
						if($Password != $Confirmed_Password){
							Message::Show("The password and its confirmation are not the same ! Try again...", Message::$Full_Size, Message::$Error);
						}
						if( empty($First_Name) || empty($Last_Name) || empty($Email) || 
						    empty($Username) || empty($Password) || empty($Confirmed_Password))
						{
							Message::Show("Enter a value for each required field !", Message::$Full_Size, Message::$Error);
						}else{
							if(!User::Email_Exists($Email) && !User::Username_Exists($Username) && $Password == $Confirmed_Password )
							{
								$userObj = new User($First_Name, $Last_Name, $Email, $Username, $Password, 2);
								$userObj->Insert();
								Message::Show("Your account is successfully created !", Message::$Full_Size, Message::$Success);
							}
						}
						
					}
				?>
    
    
  <div class="container" style="margin-top: 50px; ">
    <div class="row">
      <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
        <div class="card card-signup my-5">
          <div class="card-body">
            <h5 class="card-title text-center">Register</h5>
            <form class="form-signin" action="#" method="POST">
             
                <div class="form-label-group">
                <input type="text" name="First_Name" class="form-control" placeholder="First Name" required>
                <label for="firstName">First Name</label>
              </div>
                <div class="form-label-group">
                <input type="text" name="Last_Name" class="form-control" placeholder="Last Name" required>
                <label for="lastName">Last Name</label>
              </div>
                 <div class="form-label-group">
                <input type="email" name="Email" class="form-control" placeholder="Email address" required autofocus>
                <label for="inputEmail">Email address</label>
              </div>
                
                <div class="form-label-group">
                <input type="text" name="Username" class="form-control" placeholder="User Name" required>
                <label for="userName">User Name</label>
              </div>

              <div class="form-label-group">
                <input type="password" name="Password" class="form-control" placeholder="Password" required>
                <label for="inputPassword">Password</label>
              </div>
                <div class="form-label-group">
                <input type="password" name="Confirmed_Password" class="form-control" placeholder="Confirm Password" required>
                <label for="confirmPassword">Confirm Password</label>
              </div>

              
              <button class="btn btn-lg btn-primary btn-block text-uppercase" type="submit" name="Submit">Sign Up</button>
              <hr class="my-4">
              
            </form>
              <h6>Have an account? <a href="login.php">Sign In</a></h6>
          </div>
        </div>
      </div>
    </div>
  </div>
    
    
    

</body>