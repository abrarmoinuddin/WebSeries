
<?php include "includes/header.php" ?>
<?php include_once "../classes/User.php"?>




<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
  <div class="container">
    <a class="navbar-brand" href="index.php" style="font-size: x;">Php Project</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target=".navbar-collal" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
        
        
      <ul class="navbar-nav ml-auto">
        <li class="nav-item active">
          <a class="nav-link" href="index.php">Home
                <span class="sr-only">(current)</span>
              </a>
        </li>
          <li class="nav-item">
          <a class="nav-link" href="series_main.php">Series</a>
        
          <li class="nav-item">
          <a class="nav-link" href="search.php">Search</a>
        </li>
              
          <li class="nav-item">
          <a class="nav-link" href="favorites.php">Favourites</a>
        </li>
          
          
        
        <li class="nav-item">
          <a class="nav-link" href="Logout.php"> Logout</a>
        </li>
        
      </ul>
    </div>
  </div>
</nav>

<?php include "includes/carousel.php" ?>

<body>
	<div id="page" align="center">
		<div id="content" style="width:800px">
		
			
		</div>
	</div>
	
