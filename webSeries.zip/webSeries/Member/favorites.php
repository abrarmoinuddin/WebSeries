<?php include "includes/header.php"?>
<?php include_once "../classes/Series.php"?>
<?php include_once "../classes/Favorite.php"?>
<?php include_once "../classes/Rating.php"?>
<style>
    
   body{
            background-image: url("images/blur.jpg");   
            background-size: cover;
        
       background-position: center;

    }
    
</style>
<body>
	<div id="page" align="center">
		<div id="content" style="width:800px;padding:100px;">
			
			<?php include "includes/TopBar.php"?>
			<div id="contenttext">
		
				<div class="bodytext" style="padding:12px;" align="justify">
					
				<?php 
					if(!isset($_SESSION)){
						session_start();
					}
										
					$User_ID = $_SESSION['User_ID'];
					
					if(isset($_POST['Delete'])){
						$series_ID = $_POST['series_ID'];
						Favorite::Delete_Favorite($User_ID, $series_ID);
					}
														
					$array = series::Get_Favorite_series($User_ID);
					series::Display_member($array, TRUE);
										
				?>
				
				</div>
			</div>
			
		</div>
	</div>
	