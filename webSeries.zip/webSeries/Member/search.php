<?php   
    include"includes/header.php";
    include"includes/TopBar.php" ;
    include_once"../classes/series.php" ;

    $selected = 0;
    $checked = 0;
    $keywords = '';
if(isset($_POST['submit'])){
        $checked = $_POST["search"];
        $selected = $_POST["series"];
        $keywords = $_POST["keywords"];
}
?>



<html>
  <head>
    
    <link href="../style/main.css" rel="stylesheet" />
  </head>
    <style>
        body{
             background-image: url("images/SearchBackground.jpg");    
        }
    </style>
  <body>
    <div class="s01">
      <form>
        <fieldset>
          <legend>Looking for something...?</legend>
        </fieldset>
        <div class="inner-form">
          <div class="input-field first-wrap">
            <input id="search" type="text" placeholder="What are you looking for?" />
          </div>
         
          <div class="input-field third-wrap">
            <button class="btn-search" type="button">Search</button>
          </div>
        </div>
      </form>
    </div>
  </body>   
