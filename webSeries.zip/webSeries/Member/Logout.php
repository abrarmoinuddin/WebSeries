<?php ob_start(); 
	header('Location: ../index.php');
	
	if(!isset($_SESSION)){
		session_start();
	}
	if(!empty($_SESSION['Username'])){
		$_SESSION['Username'] = NULL;
	}
	if(!empty($_SESSION['Role_ID'])){
		$_SESSION['Role_ID'] = NULL;
	}
	if(!empty($_SESSION['User_ID'])){
		$_SESSION['User_ID'] = NULL;
	}
?>