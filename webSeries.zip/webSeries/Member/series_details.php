<?php include "includes/header.php"?>
<?php include_once "../classes/series.php"?>
<?php include_once "../classes/Sorting.php"?>
<?php include_once "../classes/Rating.php"?>




<body>
	<div id="page" align="center">
		<div id="content" style="width:800px">
			
           
            <?php include "includes/TopBar.php" ?>
			<div id="contenttext">
		
				<div class="bodytext" style="padding:12px;" align="justify">
				<?php
                    
				if(isset($_GET['ID'])){
						
						$User_ID = $_SESSION['User_ID'];
						$series_ID = $_GET['ID'];
						
						if(isset($_POST["rating"]))	{
							$rating_obj = new Rating($series_ID, $User_ID , $_POST["rating"]);
							$rating_obj->Create();
						}
						if(isset($_POST["Favorite"])){
							if(isset($_POST["Checkbox"])){
								Favorite::Add_Favorite($User_ID, $series_ID);
							}else{
								Favorite::Delete_Favorite($User_ID, $series_ID);
							}
						}
						$series = series::Search_By_ID($_GET['ID']);
						series::Display_Detail($series, $_SESSION['User_ID']);
					}
					
				?>
				
				
				</div>
			</div>
		</div>
	</div>
	