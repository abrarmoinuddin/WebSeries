<?php 
require_once "Database.php";
include_once "Favorite.php";
include_once "Rating.php";
class Series{
		
	private $ID;
	private $Name;
	private $Creator;
	private $Episodes;
	private $Seasons;
	private $Genres;
	private $Language;
	private $Image;
	
	function Series($Name,$Creator,$Episodes,$Seasons,
	                     $Genres,$Language,$Image, $ID = null){
		$this->ID = $ID;
		$this->Name = $Name;
		$this->Creator = $Creator;
		$this->Episodes = $Episodes;
		$this->Seasons = $Seasons;
		$this->Genres = $Genres;
		$this->Language = $Language;
		$this->Image = $Image;
	}
		
	
	public function Create(){
		
		$database = Database::Get_Instance();
		$connection = $database->GetConnection();
		try{
			$query  = "INSERT INTO series(Name, Creator, Episodes, Seasons, Genres, Language, Images) ";
			$query .= " VALUES(?, ?, ?, ?, ?, ?, ? )";
		
			$stmt = $connection->prepare($query);
			$stmt->bindParam(1,$this->Name);
			$stmt->bindParam(2,$this->Creator);
			$stmt->bindParam(3,$this->Episodes);
			$stmt->bindParam(4,$this->Seasons);
			$stmt->bindParam(5,$this->Genres);
			$stmt->bindParam(6,$this->Language);
			$stmt->bindParam(7,$this->Image);
		
			$stmt->execute();
			
			return $connection-> lastInsertId();
			
		}catch(PDOException $e){
			echo "Query Failed ".  $e->getMessage();
		}
	}
	public static function ReadSeries(){
		
		try{
		
			$query = "SELECT * FROM series";
			$database = Database::Get_Instance();
		    $connection = $database->Get_Connection();
			$statement  = $connection->prepare($query);
			$statement->execute();
			
			$result = $statement->fetchAll(PDO::FETCH_ASSOC);
			
			return $result;
			
		}catch(PDOException $e){
			echo "Query Failed : ".$e->getMessage();
		}	
		
	}
	public static function Get_Favorite_Series($User_ID){
        try{
			$query = "SELECT * FROM series INNER JOIN favorites ON series.ID = favorites.series_ID AND favorites.User_ID = $User_ID ";
			
			$database = Database::Get_Instance();
			$connection = $database->Get_Connection();
			$statement = $connection->prepare($query);
			$statement->execute();
			
			return $statement->fetchAll(PDO::FETCH_ASSOC);
        
		}catch(PDOException $e){
			echo "Query Failed ".$e->getMessage();
		}
    }
	public static function Search_By_ID($series_id){
		try{
			$query = "SELECT * FROM series WHERE ID = $series_id";
			$database = Database::Get_Instance();
			$connection = $database->Get_Connection();
			$statement = $connection->prepare($query);
			$statement->execute();
			return $statement->fetch(PDO::FETCH_ASSOC);
			
		}catch(PDOException $e){ 
			echo "Query failed ".$e->getMessage();
		}
	}
	public static function Calculate_Rating($series_id, $user_id = NULL){
		
		try{
			$query = "";
			if(empty($user_id)){
				$query = "SELECT AVG(Rating) FROM ratings WHERE series_ID = $series_id";
			}else{
				$query = "SELECT AVG(Rating) FROM ratings WHERE series_ID = $series_id AND User_ID = $user_id";
			}
			$database = Database::Get_Instance();
		    $connection = $database->Get_Connection();
			$statement  = $connection->prepare($query);
			$statement->execute();
			
			$result = $statement->fetch(PDO::FETCH_ASSOC);
			
			return $result["AVG(Rating)"];
			
		}catch(PDOException $e){
			echo "Query Failed : ".$e->getMessage();
		}			
	}
	public static function Get_Images($array){
		$images = array();
		foreach($array as $row){
			array_push($images, $row['Image']);
		}
		return $images;		
	}

	public static function Display_Detail($row, $user_id = NULL){
		echo '<div class="card mx-auto w-100">';
		echo '<div class="row no-gutters">';
		echo '<div class="col-md-6">';
		echo '<img src="images/series/'.$row['Image']." \" height = 'auto' width = '200px'>";
		echo '</div>';
		
		echo '<div class="col-md-5">';
		echo "<font color = #CC0000><h6>Price: </font> $".$row['Name']."</h6>";
		echo "<font color = #CC0000><h6>Year: </font>". $row['Year']."</h6>";
		echo "<font color = #CC0000><h6>Model: </font> ".$row['Creator']." </h6>";
		echo "<font color = #CC0000><h6>Seasons: </font>". $row['Seasons']."</h6>";
		echo "<font color = #CC0000><h6>Episodes: </font> ".$row['Episodes']."</h6>";
		echo '</div>';
		echo '<div class="col-md-1">';
		echo '</br>';
		echo "<a href='series.php'>";
		echo "<button class='btn btn-secondary'><span class='fa fa-caret-left'></span></button>";
		echo "</a>";
		echo '</div>';
		echo '</div>';
		echo '<div class="card-footer">';
		echo '<div class="row no-gutters">';
		echo '<div class="col-md-4">';
		echo "<font color = #CC0000><h6> Average Rating: </font></h6><br>";
			Rating::Display_Stars(self::Calculate_Rating($row['ID']));
		echo '</div>';
		echo '<div class="col-md-4">';
		if(!empty($user_id)){
			$user_rating = series::Calculate_Rating($row['ID'], $user_id);
			Rating::Display_Form(Round($user_rating, 1));
		}
		echo '</div>';
		echo '<div class="col-md-4">';
		if(!empty($user_id)){
			$isFavorite = Favorite::IsFavorite($user_id, $row['ID']);
			Favorite::Display_Add_Form($isFavorite);
		}
				
		echo '</div>';
		echo '</div>';	
		echo '</div>';
			
	}
    
    
    
    
	public static function Display($array, $isFavoriteList = FALSE){
	
		foreach($array as $row){
			echo '<div class="card mb-2 mt-2 w-100"><div class="card-body" style= "background-image:url(images/blur.jpg)" >';
			echo '<div class="row no-gutters">';
				echo '<div class="col-md-6">';
					echo "<a href='series_details.php?ID=".$row['ID']."'>";
					echo '<img src= "images/series/'.$row['Image']." \" height = 'auto' width = '250px'>";
					echo "</a>";
				echo '</div>';
			
				echo '<div class="col-md-5" style = "background-image: url(images/card1.jpg) opacity:inherit">';
					echo "<font color = #CC0000><h2>". $row['Name']." <h2><h6> ".$row['Creator']." ".$row['Year']."</h6></font>";	
            
            Rating::Display_Stars(self::Calculate_Rating($row['ID']));
					echo "<br><br>";
					echo "<a href='series__details.php?ID=".$row['ID']."'>View Details >> </a>";
				echo '</div>';
				
				echo '<div class="col-md-1">';
				if($isFavoriteList){
					Favorite::Display_Delete_Form($row['ID']);
				}
					
				echo '</div>';
			echo '</div>';
		    echo '</div></div>';
		}
	}
    
    public static function Display_member($array, $isFavoriteList = FALSE){
	
		foreach($array as $row){
			echo '<div class="card mb-2 mt-2 w-100"><div class="card-body" style= "background-image:url(images/blur.jpg)" >';
			echo '<div class="row no-gutters">';
				echo '<div class="col-md-6">';
					echo "<a href='series_details.php?ID=".$row['ID']."'>";
					echo '<img src= "images/series/'.$row['Image']." \" height = 'auto' width = '250px'>";
					echo "</a>";
				echo '</div>';
			
				echo '<div class="col-md-5" style = "background-image: url(images/card1.jpg) opacity:inherit">';
					echo "<font color = #CC0000><h2>". $row['Name']." <h2><h6> ".$row['Creator']." ".$row['Year']."</h6></font>";	
            
            Rating::Display_Stars(self::Calculate_Rating($row['ID']));
					echo "<br><br>";
					echo "<a href='series_details.php?ID=".$row['ID']."'>View Details >> </a>";
				echo '</div>';
				
				echo '<div class="col-md-1">';
				if($isFavoriteList){
					Favorite::Display_Delete_Form($row['ID']);
				}
					
				echo '</div>';
			echo '</div>';
		    echo '</div></div>';
		}
	}
}
?>



 